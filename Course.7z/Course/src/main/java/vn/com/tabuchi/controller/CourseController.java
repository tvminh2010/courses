package vn.com.tabuchi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import vn.com.tabuchi.entity.Author;
import vn.com.tabuchi.entity.Category;
import vn.com.tabuchi.entity.Course;
import vn.com.tabuchi.repository.IAuthor;
import vn.com.tabuchi.repository.ICategory;
import vn.com.tabuchi.repository.ICourseRepository;

@RestController
@RequestMapping("/courses")
public class CourseController {
	
	@Autowired
	ICourseRepository courseRepository;
	@Autowired
	IAuthor authorRepository;
	
	@Autowired
	ICategory categoryRepository;
	
	/* ------------------------------------------- */
	@GetMapping("")
	public ResponseEntity<?> allCourses() {
		List<Course> courses = courseRepository.findAllCourseAndGetCategory();
		List<Category> categories = categoryRepository.layAllCategory();
		List<Author> authors = authorRepository.findAll();
		
		
		return ResponseEntity.status(HttpStatus.OK).body(courses);
		//return ResponseEntity.ok("fdsfdsf");
	}
	/* ------------------------------------------- */
}
