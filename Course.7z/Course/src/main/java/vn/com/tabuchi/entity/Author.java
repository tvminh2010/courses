package vn.com.tabuchi.entity;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="tbl_author")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Author implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	private String name;
	private String email;
	private String mobile;
	private String address;
	
	
	@OneToMany(cascade=CascadeType.ALL, 
			mappedBy="author", 
			fetch = FetchType.LAZY,
			orphanRemoval = true)
	private Set<Course> courses;
}