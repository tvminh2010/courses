package vn.com.tabuchi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import vn.com.tabuchi.entity.Author;

public interface IAuthor extends JpaRepository<Author, Integer> {

}
