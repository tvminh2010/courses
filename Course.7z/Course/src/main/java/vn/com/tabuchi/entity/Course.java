package vn.com.tabuchi.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="tbl_course")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Course implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	private String title;
	@Column(name="dis_count")
	private Integer discount;
	private String description;
	private Boolean active;
	@Column(name="unit_price")
	private BigDecimal unitPrice;
	@Column(name="image_url")
	private String imageUrl;
	@Column(name="video_url")
	private String videoUrl;
	@Column(name="date_created")
	private Date createdOn;
	@Column(name="last_updated")
	private Date updatedOn;
	/* ----------------------------------------------- */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="category_id", nullable=false)	
	private Category category;
	/* ----------------------------------------------- */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="author_id", nullable=false)
	private Author author;
	/* ----------------------------------------------- */
	/*
	@OneToMany(mappedBy = "course",
			cascade = CascadeType.ALL,
		    orphanRemoval = true)
	private List<CourseUser> courseUsers = new ArrayList<>();*/
	/* ----------------------------------------------- */
}
