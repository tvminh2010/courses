package vn.com.tabuchi.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CourseUser implements Serializable {

	private static final long serialVersionUID = 1L;
	/* --------------------------------------------------- */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Size(min = 1, max = 5)
	private Integer rating;
	/*
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id")
	private User user;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "course_id")
	private Course course;
*/
	/* --------------------------------------------------- */
	/*
	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || this.getClass() != o.getClass())
			return false;
		CourseUser that = (CourseUser) o;
			return Objects.equals(user, that.user) &&
				Objects.equals(course, that.course);
	   }*/
	/* --------------------------------------------------- *//*
    @Override
    public int hashCode() {
        return Objects.hash(user, course);
    }*/
    /* --------------------------------------------------- */
}