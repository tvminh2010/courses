package vn.com.tabuchi.repository;

import java.util.List;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.EntityGraph.EntityGraphType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import vn.com.tabuchi.entity.Category;

@Repository
public interface ICategory extends JpaRepository<Category, Integer> {
	
	@EntityGraph(value="graph.category.courses", type = EntityGraphType.LOAD)
	List<Category> findAll();
	
	@Query("SELECT DISTINCT ca, c FROM Category ca JOIN ca.courses c")
	List<Category> layAllCategory();
}
