package vn.com.tabuchi.model.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CourseDto {
	private String title;
	private Integer discount;
	private String description;
	private Boolean active;
	private BigDecimal unitPrice;
	private String imageUrl;
	private String videoUrl;
	private Date createdOn;
	private Date updatedOn;
}
